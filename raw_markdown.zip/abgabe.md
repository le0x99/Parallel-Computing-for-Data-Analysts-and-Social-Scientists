Author :  Leonard Vorbeck
Text   :  Markdown, LaTeX, HTML, JavaScript
Code   :  Python
# Efficient Data Acquisition and Preprocessing

## 0 - Introduction

Data Science and Advanced Analytics has been a rapidly growing market in the past years[<cite><a href="https://www.forbes.com/sites/gilpress/2013/05/28/a-very-short-history-of-data-science/#47598ed355cf">source</a></cite>], especially since the fields "Big Data" and "Machine Learning" emerged. While most of the formal methods were already well understood decades before, the computational feasability and the corresponding implementation have improved dramatically over the past years, making it possible for almost anyone with basic technical knowledge to apply state of the art analytics. That being said, the application of those models is not where the major workload of an analyst or data scientist is allocated. Rather than spending time on the formalization and implementation of a fancy model, the majority of an analyst's time is spend on acquiring, cleaning, restructuring and transforming data, commonly known as data gathering and preprocessing. The actual percentage of time spent on doing this kind of work is undefined, various sources state 80% or more[<cite><a href="https://www.forbes.com/sites/gilpress/2016/03/23/data-preparation-most-time-consuming-least-enjoyable-data-science-task-survey-says/#63d7e56e6f63">source</a></cite>].
In this paper I will discuss the basics of data acquistion and preprocessing from a researcher's point of view, common obstacles when doing so and I will particularly talk about efficiency due to the parallelization of code.
###  The relation to Economics and social sciences in general

The relation between the subject (data prep) and social sciences (here Economics) may not be obvious at first glance, but let me try to explain the importance of the subject in regards to social sciences in general : 
Social sciences deal with governments, nations, markets and more, but it does not matter which subfield we are looking at, since the most fundamental research subject of all social sciences is basically people. Dealing with people means it would be desirable to have data about people. Traditionally this kind of data has been obtained via local experiments or polls, which are still viable sources of information, but those classic forms of social experiments have considerable limitations and drawbacks, where small sample sizes, baeurocacry and costs aren't even the big concerns to start with. In contrast to classic social experiments, the "people-data" which can be found on the web, especially in social media, is at a completely different scale when it comes to dimensionality, volume and consistency. Next to the described advantages there are other things regarding the nature of the data (The data is commonly created by the behaviour of the user itself, without even knowing it) which generally make them much more valuable than common experimental data. While I dont want to go any depper into this topic (Further read : [<cite><a href="https://link.springer.com/article/10.1007/s12651-010-0042-6">source</a></cite>]), i hope that at this point it may be a bit more clear why knowing how to retrieve and structure data is and will become a valuable tool for any social scientist.


## 1 - Acquiring Data

The process of localizing and gathering data is not a trivial task and should not be underestimated in terms of expected time expenditures. While the necessary worksteps to obtain data is generally dependant on availability and volume, even highly available, low volume data can be tricky to obtain. This is especially true for corporations with existing data pipelines, where the codebase is maintained poorly. In this paper i will talk more about the data acquisition process from a university-researchers point of view by discussing potential data sources.


### Public Data Sets
The most straight-forward-way to find the desired information is to query the web for publicly available datasets. This kind of data has already been cleaned and structured most of the time, making it an easy to access source of information. Common hosts are the famous UCI MLREPO[<cite><a href="http://archive.ics.uci.edu/ml/">source</a></cite>] or Kaggle[<cite><a href="https://www.kaggle.com/datasets">source</a></cite>], but also the data sets provided by the governments like DESTATIS[<cite><a href="https://www.destatis.de/DE/Home/_inhalt.html">source</a></cite>] or open databases like OSM[<cite><a href="https://www.openstreetmap.com">source</a></cite>]  usually provide good quality data in almost any format, which is especially interesting for economists. While the accessibility of those data sets is very high, chances are the researcher obtains data which has already been applied to all known methods and explorations making it less suitable for extracting novel insights.

###  APIs 
Another way of obtaining data is to use APIs from a platform of interest. An API (Application Programming Interface) has a very broad definition, but its generally describing an interface for some service, where a user/employee/... can request information/functions/... . In this paper I discuss APIs as a way to retrieve information. While there are endless APIs in the web, I will primarly talk about social media APIs, which (for a social scientist) represents a potential source of valuable data. The API landscape has become very large over the last decades. Services like Facebook, twitter or flickr have constantly expanded their open access APIs with the intention to improve their services by letting external users have access to their data and build applications on their platforms. Unfortunately, this trend has reversed, more on that later. Obviously, a researcher's intent is not to create apps on facebook, but to collect data. The proccess of gathering data from APIs is generally always the same procedure : First, the researcher has to choose his programming language of choice and get an API-key to gain access to the platforms services(There are also some APIs which provide web interfaces, but they are usually not scalable). Next, it is necessary to read the documentation in order to find out about the APIs capabilities and its limitations. Reading and understanding the documentation can be lengthy, some APIs are documented poorly, but it is very important, because it is mandatory to understand how the API is designed, how the returned data is structured and what datatypes are used. As an example consider this simplified JSON-Responses for two distinct business entities in Heidelberg :

```javascript
// Request 0
var response_0 = {
                     "ENTITY_ID" : 31032,
                     "NAME"      : "Café Botanik",
                     "LOCATION"  : (49.4152294,8.6681458),
                     "ADDRESS"   : { 
                                     "STREET" : "Im Neuenheimer Feld",
                                     "HNUMBER": "304"
                                   },
                     "RATING"    : 4.5,
                     "CATEGORIES": ["Restaurant", "Cafe", "Social"]
                 }

// Request 1
var response_1 = {
                     "ENTITY_ID" : 29812,
                     "NAME"      : "Halle02",
                     "LOCATION"  : (49.4021062,8.668602),
                     "ADDRESS"   : { 
                                     "STREET" : "Zollhofgarten",
                                     "HNUMBER": 2
                                   },
                     "RATING"    : 3.7,
                     "CATEGORIES": "Party"
                 }
                 
```
This example demonstrates a common obstacle when dealing with APIs, namely *data inconsistency*. If you look at `response_0` the returned house number is a string, while in `response_1` it is an integer. Even worse: `"CATEGORIES"` is returned as an array if there is more than one category associated with the entity. Things like this are important to know before hardcoding some gathering algorithm, because small inconsistencies like this can cause large problems later on. Depending on the API and its documentation it may be necessary to write some code for automatically detecting inconsistencies.

Another commmon obstacle when dealing with APIs is its limitations. Almost all (not all) of the newer APIs have a limited usage policy, which normally means that the total amount of request is limited per time unit. The researcher therefore needs to approximate the amount of requests he wants to make and do the math in order to not run idle within the data acquisition process.


###  Advanced data acquisition techniques

Using APIs is much more time consuming than using public data sets, but it is still considered a convenient method to acquire data. I will now briefly discuss some alternative ways to obtain data, namely *data harvesting* in general, which is mainly associated with Web Scraping, but there are numerous other sources than the web where information is being extracted, restructured and stored.


#### Web Scraping
Web scraping is a technique of extracting information from the internet, usually transforming unstructured data on the web into structured data that can be stored and analyzed[<cite><a href="https://en.wikipedia.org/wiki/Web_scraping">source</a></cite>]. As a researcher who wishes to analyze data which he is unable to get access to, the goal is to built an automated tool which acquires the data (often refered to as "bots"). That being said, web scraping is a well understood topic and an ubiquitous part of the internet (Bots make up approx. 40% of all web traffic[<cite><a href="https://resources.distilnetworks.com/white-paper-reports/bad-bot-report-2019">source</a></cite>]). Since the API-landscape has altered in a way that made it harder for researchers to freely access data in the web(especially the valuable "people-data" found on social media platforms), web scraping can be good alternative for acquiring data. Fortunately, scraping has become fairly easy thanks to the development of high-level libraries such as ```requests``` or ```rvest```. However easy the implementation, there are big differences regarding the scale of the scraper:

- Technical Necessities

For small scraping project there is no additional technical knowledge (other than programming) required, because most webbrowsers provide a graphical interface for the inspection of source code. When it comes to more serious projects basic HTML and especially ReGeX are necessary to learn.

- Dealing with Defense Algorithms

Most websites do not prohibit the extraction of data, but they still try to decrease bot traffic on their servers. In order to do that "bad bots" are identified and IP-banned. A bad bot is a bot who extensively queries information from a site, in a way that impacts the overall server performance negatively. Those kind of bots are easy to detect for any defense algorithm. For low scale projects decreasing the frequency is usually enough to avoid getting banned. For large scale projects the defense algorithm needs to be analyzed and bypassed.

- Security

Many sites, especially social media sites, prohibit users from scraping their sites, because the extraction of data violates their terms of service. For example see  <cite><a href="https://www.facebook.com/apps/site_scraping_tos_terms.php">Facebook's Terms of Service</a></cite> . While I do not recommend nor encourage any researcher to violate the ToS of any company, needless to say avoiding being identified requires advanced operational security.



####  Document Scraping
Common scraping targets next to the web are documents and text files, such as publicly emitted documentations, PDFs or corporate reports. For example, an economist may wish to obtain the newest information about certain variables about the economy. This kind of data is usually emitted frequently by governmental instituitons like the BKA[<cite><a href="https://www.bka.de/DE/AktuelleInformationen/StatistikenLagebilder/PolizeilicheKriminalstatistik/pks_node.html">source</a></cite>]. It is very uncertain that this information is released in a format which the researcher can instantly use for his analysis (e.g updating his models), more likely the researcher has to build some sort of automated data extraction tool, which structures and stores the file in the desired format. Note that building this kind of tools is considerably harder than scraping the web, but the skills which are useful for webscraping also apply here, especially ReGex is absolutely mandatory. Next to frequentially emitted reports it is also possible to extract raw metadata from virtually everything one could imagine: hardware such as IoT devices, logfiles or even pictures, just to name  a few[<cite><a href="https://www.forensicswiki.org/wiki/Document_Metadata_Extraction">source</a></cite>]. While this data sources may not sound promising at first, they can provide extremely valuable information if handled properly. A useful tool for this kind of data extraction is FOCA *(Fingerprinting Organizations with Collected Archives)* [<cite><a href="https://github.com/ElevenPaths/FOCA">source</a></cite>]. Unfortunately, describing this kind of tools and how they may be valuable for a data scientist, is beyond the scope of this whitepaper, but I hope this can give an overview about what is possible when it comes to acquiring exotic data.

## 2 - Data Preproccessing
I will now briefly elucidate the basic principles of data preprocessing, which mainly consists of cleaning, structuring and transforming  data in order to make it suitable for analysis and exploration. Cleaning and transforming data is, next to acquiring it, a critical part of the overall process. As described in the introduction, formalizing and implementing a fancy model is worthless, if the data is malformed due to poor acquisition/cleaning. In the context of data acquisition as discussed earlier, preprocessing data is often "integrated" within the data gathering proccess and not strictly split.
###  Cleaning Data
Data cleansing is by nature a heterogeneous process, that is why I dispense with an extensive definition, but rather explain two important characteristics of *dirty data* in general. If *dirty data* is defined, it can be identified and dealt with. 
- Incomplete Data

The most obvious type of dirty data is incomplete data. For a given data set, the researcher must find missing values within the observations. This is usually done automatically by most data analysis software. Next, the researcher has to decide how to deal with missing values, he could either impute the values (e.g using the feature mean) or discard the whole observation. This is dependant on the subject of analysis and the volume of the remaining (clean) data. 

- Inconsistent Data

Arguably the most critical kind of dirty data is data that shows inconsistencies regarding its format or datatype. The previously shown example of an API-Response demonstrates a form of datatype inconsistency. This kind of dirty data can be difficult to identify. It can become even more difficult to identify format inconsistencies : If the researcher does not have subject expertise, he might not be able to identify inappropiate measurement units. A very common type of data inconsistency is dirty data due to malformed strings. This kind of inconsistency is mainly caused by I/O and can be treated by validating the string format (Again, understanding and using ReGeX is very helpful).

There are many other forms of dirty data, but the two forms mentioned above are the most likely to occur.

### Transforming, Restructring and Storing Data
Much like data cleansing, data transformation is a very heterogenous process which depents on the analysis purpose. In Data Science this process is often associated with making the data suitable for modeling[<cite><a href="https://en.wikipedia.org/wiki/Data_transformation_(statistics)">source</a></cite>] One could argue about whether Feature Engineering is part of preprocessing or whether it is part of the actual analysis, however there are other questions which need to be adressed regarding the transformation of data:
- What kind of analysis will be run on the data?

- Who will use the data other than the researcher?

- How should the data be stored?

- [...]

The researcher needs to address those questions after the acquisition process is complete.



## 3 - Efficiency and Scalability
Data Acquisition and Data Preprocessing have in common that both require potentially large amounts of data to be processed, which makes both processes vulnerable to inefficient work habits and therefore can waste a lot of ressources. I will now explain how the parallelization of existing code can help to create scalable and efficient tools. Unfortunately I will not provide an in-depth explaination of parallel computing, since its just too broad of a topic, but I will discuss the core principles as well as some hands on examples regarding the subject.

<img src="mähdrescher.jpg" width="1600" height="600" align="left" />

*Image-Source :  http://bingbilder.com/uploads/1290985200.jpg*

###  Parallel Computing

Traditionally, software has been designed to be executed *sequentially* by a central processing unit (CPU). Any problem is basically a set of instructions which is send to the CPU in order to be executed as shown below. Note that the instructions are executed sequentially, where only one instruction may execute at any moment in time. In contrast to that Parallel Computing involves using multiple processing units simultaniously to solve a problem. The initial problem is split into discrete parts that can be solved concurrently, where each part is further broken down into a set of instructions. Additionally, a control mechanism has to be implemented. 

<img src="picture.png" width="1600" height="600" align="left" />

####  Motivation Example 

Before I explain why the parallelization of code is especially useful for data scientists, I start with a very basic motivation example.
Consider a researcher who built a *custom* ensemble model. Fitting the model is computational intensive. The model takes $10$ parameters. For a given set of parameters, the computing time is deterministic with $x\sec$ per fit. There are $n$ parameter sets, which need to be evaluated. The overall task will take $n*x\sec$.


```python
import numpy as np, pandas as pd
from time import sleep
```

Consider $n, x\gets 12, 5$




```python
fancy_model = lambda *args : sleep(5) #simulate some heavy computations
```


```python
params = np.random.random((12, 10)) #generate random param-sets   
params.shape
```




    (12, 10)



The computing time will be about $12*5\approx60\sec \approx 1\min$


```python
%time results = [ fancy_model(param_set) for param_set in params ]
```

    CPU times: user 2.68 ms, sys: 2.74 ms, total: 5.42 ms
    Wall time: 1min


#### Quick Parallelization
Dask[<cite><a href="https://github.com/dask/dask">source</a></cite>] is only one of many high-level libraries for parallelization. I use it because it has advanced performance diagnostics and the implementation on clusters is fairly easy.


```python
from dask import delayed, compute
```


```python
%time lazy_results = [ delayed(fancy_model)(param_set) for param_set in params ]
```

    CPU times: user 1.76 ms, sys: 177 µs, total: 1.94 ms
    Wall time: 1.99 ms


The computations are coordinated within the `lazy_results` object, which means the results arent computed yet, but ready to be computed by parallel hardware ( the researcher could submit this object to a remote cluster for example ). In the next step the delayed results are submitted to a worker pool, in this case I will use my local machine to compute the results.


```python
%time result = list(compute(*lazy_results)) 
```

    CPU times: user 18.5 ms, sys: 6.54 ms, total: 25 ms
    Wall time: 15 s


Due to parallelization, the computation is accelerated by a factor of $4$. Why and how will be discussed.

This toy-example does not show the capabilities of parallelizing code in any way, what it does however is demonstrating how a minor change in the "Coding-Style" quarters the time the researcher needs to evalute his model. Just imagine higher values for $x$.

###  Why write parallel code? 
- Make more use of the underlying hardware

First of all, most modern machines are designed to work parallel from a hardware perspective[<cite><a href="https://en.wikipedia.org/wiki/Multi-core_processor#Trends">source</a></cite>], even my laptop, as demonstrated above. This fact makes the topic accessible for virtually anyone who uses his/her laptop to try parallelize his/her code in order to not waste time and ressources.

- In Data Science many Problems are *embarassingly* easy to parallelize

Data scientists have an important advantage over software engineers when it comes to parallelizing code. While SE's have to deal with large and complex codebases, a data scientist usually doesn't write any serious code. In fact most of a data scientist's concerns regarding computational time is due to data volume. This often means applying a function on potentially large amounts of data. Why some tasks are easier to parallelize than others will be clear later.

- Save Time and Money - execute efficiently

The most obvious reason to parallelize code is to save time and therefore money. Generally speaking, the more ressources the researcher is able to manage, the faster he can solve problems, in the case of this whitepaper, the process of gathering and transforming data can be accelerated dramatically if the code is paralleized properly. In theory the speedup of parallelized code can be measured using *Amdahl's Law*, where to potential speedup $SU$ is determined by the partial fraction of the code which can be parallelized ($P$).

$$
SU = \frac{1}{1-P}
$$



```python
import pandas as pd, numpy as np, matplotlib.pyplot as plt
```


```python
pd.Series([1/(1-P) for P in np.linspace(0., .99,10000)], index=np.linspace(0., .99,10000)).plot(title="Theoretical  Speedup")
                                                                                                
plt.legend(["$SU(P)$"]), plt.xlabel("$P$"), plt.ylabel("$SU$")
```




    (<matplotlib.legend.Legend at 0x11c7106d8>,
     Text(0.5, 0, '$P$'),
     Text(0, 0.5, '$SU$'))




![png](output_22_1.png)


If none of the existing code can be parallelized $SU$ gets 1 (no speedup), for $P=1$ the speedup is theoretically infinite. By introducing the number of processors $N$, the limitations of parallel computing get more clear:

$$
SU = \frac{1}{\frac{P}{N} + S}
$$

Where $S$ denotes the serial fraction of the code ($S+P=1$)


```python
[ pd.Series([1/((P/N)+(1-P)) for N in range(1,801)]).plot(title="Theoretical  Speedup") for P in [.95,.9,.8,.5] ]
plt.legend(['$P=%f$' % i for i in [.95,.9,.8,.5]]), plt.xlabel("$N$"), plt.ylabel("$SU$")
```




    (<matplotlib.legend.Legend at 0x11cfe3ac8>,
     Text(0.5, 0, '$N$'),
     Text(0, 0.5, '$SU$'))




![png](output_24_1.png)


Famous Quote : *"You can spend a lifetime getting 95% of your code to be parallel, and never achieve better than 20x speedup no matter how many processors you throw at it!"*

If we refer to the motivational example, we see that the expected speedup was right on point.


```python
from os import cpu_count as N
N() == 4
```




    True



Since $N = 4$ and $P=1$ we would have excepted a speedup of $4$. We could even test Amdahls Law a second time by increasing the param-set size from $12$ to $15$.


```python
params = np.random.random((15, 10))  
```

The (serial) computing time will be about $15*5\approx75\sec \approx 1.25\min$


```python
%time results = [ fancy_model(param_set) for param_set in params ]
```

    CPU times: user 57.9 ms, sys: 16.4 ms, total: 74.3 ms
    Wall time: 1min 15s


Now lets have a look at the parallelized version :


```python
%time lazy_results = [ delayed(fancy_model)(param_set) for param_set in params ]
```

    CPU times: user 2.06 ms, sys: 1.08 ms, total: 3.14 ms
    Wall time: 2.2 ms


We would now expect a speedup smaller than $4$ because, the *work pool* with $n=15$ is now unevenly distributed among the workers ($N=4$), which makes $P<1$ and therefore $S>0$, which yields $SU<4$.


```python
%time results = list(compute(*lazy_results))
```

    CPU times: user 21.8 ms, sys: 6.98 ms, total: 28.7 ms
    Wall time: 20 s


As expected $SU \approx 3.75$. Finally, consider increasing $n$ to $40$.


```python
params = np.random.random((40, 10))  
```


```python
%time lazy_results = [ delayed(fancy_model)(param_set) for param_set in params ]
```

    CPU times: user 5.56 ms, sys: 2.09 ms, total: 7.65 ms
    Wall time: 6.98 ms



```python
%time results = list(compute(*lazy_results))
```

    CPU times: user 55 ms, sys: 16.3 ms, total: 71.3 ms
    Wall time: 50 s


For 40 we gain a speedup of $\frac{200}{50}=4$ again. Although this is a very superficial example, I hope it will help give a first impression of the changes that are required to write parallel code.

### General concepts and terminology
While it is often not necessary to understand what's going on in the background when writing code, in parallel computing it is mandatory, regardless of the fact that the actual implementation has become very high level.
*Note* : I assume that the reader is familiar with basic computer architecture, namely <cite><a href="https://en.wikipedia.org/wiki/Von_Neumann_architecture">Von-Neumann-Architecture</a></cite>. I refer to *workers, processing units and cores* as the CPU described in this archticture.
##### Flynn's Taxonomy - Classifying Computational Work
Introducing a more general classification method will help to understand the core principles of parallel computing. Flynn's taxonomy seperates computing architectures according to their data and instruction streams. 

- Single Instruction, Single Data (SISD)

A serial computer in the classic sense (typically a single core machine), where *only one instruction stream and data stream* can be submitted to the processor of the machine *during any one clock cycle*.

<img src="SISD.png" width="1600" height="600" align="left" />

- Single Instruction, Multiple Data (SIMD)


All processors execute the same instruction at any given clock cycle, where each processing unit can operate on a different subset of the data. This type of parallelization is especially interesting for data scientists. SIMD-Systems represent the simplest form of parallel computing

<img src="SIMD.png" width="1600" height="600" align="left" /> 

- Multiple Instruction, Single Data (MISD)

In this type of parallel computing model, the distinct processing units hold different instructions while operating independently on the same data. In the data science context, imagine training multiple models simultaniously.


<img src="MISD.png" width="1300" height="600" align="left" />

- Multiple Instruction, Multiple Data(MIMD)

A computing model in which each processing unit is able to hold different instructions on distinct data streams. Different processors may be working completely independant from one another. 


<img src="MIMD.png" width="1600" height="600" align="left" />

*Image-Source :  Blaise Barney, Lawrence Livermore National Laboratory*

#### Basic Memory Architecture
An important part of actually implementing a parallel system is to understand what kind of memory architecture should be used. Although discussing parallel systems on a hardware level would be beyond the scope of this paper, I think it is helpful to understand regarding the overall concept. Fundamentally, there are two different types of memory architectures :

- Shared Memory


The shared memory archticture enables all processors within the system to equally access a global memory space. Practically speaking, the globally allocated memory allows the processors to operate independently from one another, while accessing the same resources. This approach is simple and user-friendly, but it comes with a major drawback : It is not easy to scale up a shared memory architecture, because it is not possible to just increase the number of workers in the system, because the traffic on the global memory will increase and therefore the need to manage the data streams between the processing units. <cite><a href="https://en.wikipedia.org/wiki/Symmetric_multiprocessing">SMP</a></cite> is an example of how shared memory architectures work on most of modern computers.

- Distributed Memory

This architecture is characterized by the fact that each processor has its own local memory on which it can operate independently, resulting in less memory management (no cache coherency). That being said the system requires an inter-processor-communication network, since there is no global memory.
The biggest advantage of this architecture is the fact that it is relatively easy to extend this system with new processors, as each newly added processor has its own memory. The disadvantage is that a communication and synchronization structure is now required which has to be implemented by the programmer.
Computer clusters are often set up with a hybrid form of the two mentioned concepts.[<cite><a href="https://computing.llnl.gov/tutorials/parallel_comp/">source</a></cite>]


#### Designing parallel programs
There are various programming models for parallel computing, each of which can be viewed as a high level abstraction that helps to structure a problem in order to solve it in a parallel way.[<cite><a href="https://computing.llnl.gov/tutorials/parallel_comp/">source</a></cite>] I could introduce the different models, but rather I would like to introduce the fundamental questions that every programmer, regardless of the programming model, has to answer when attempting to parallelize code.
First of all, the programmer needs to understand the problem he wishes to solve, because he needs to determine wether or not the problem is able to be parallelized at all. While there are problems that can be solved in parallel with little effort (*embarassingly parallel*), there are problems which are extremely hard to solve in parallel naturally (*embarassingly sequential*). In this context, the programmer needs to decide if its worth the time deploying parallel code at all. Best practice when detecting major inhibitors to parallelism is to to write serial code or find other algorithms which are easier to parallelize. This is especially true when dealing with recursive functions. As an example consider the Fibonacci series with the formula : $F(n) = F(n-1) + F(n-2)$, which offers little chance to parallelize if expressed recursively. 
Again, deciding if the problem should be solved concurrently at all is crucial. The overhead costs associated with a parallel environment can be greater than the actual gain, additionally the programmers time to implement the system must be considered. 

#### Designing parallel programs - Elements of parallel software
In order to approximate the associated *overhead* and *implementation wokload* the fundamental questions are now addressed :

### I) How to decompose the problem?

The first step is to break the initial problem down into discrete parts of computational work that can be distributed among the workers (In this case a worker represents a processing unit).
There are two ways to partition the work and its the task of the researcher to determine which to use.


-  Domain Decomposition

In this approach, the data (domain) is split. Each worker is assigned to work on a portion of the initial data. In the data science context, many computationally intense problems are parallelized by decomposing the data.

<img src="data_dec.png" width="350" height="550" align="left" />

-  Functional Decomposition
    
Functional Decomposition describes the process of breaking down the actual algorithm of the problem. This usually requires a much deeper understanding of the the problem. If the researcher is able to split the initial problem into a set of smaller problems, parts of the problem may be executed in parallel. 

<img src="func_dec.png" width="350" height="550" align="left" />
    

At the end of this paper I will provide a more clear example of how functional decomposition could look like in practice.

### II) Is communication between the workers necessary?
Task communication in the context of parallel computing describes the process of exchanging data between the workers of a parallel system. It depends on the problem if the workers need to communicate at all. *Embarassingly parallel* problems like the motivation example, need little to no communication at all, while other problems require the tasks to communicate (The cumulative sum of an array could serve as an example here). Communication is always associated with overhead. On the one hand the workers need to use ressources to communicate which could be used for computation, on the other hand the latency of the messages and the bandwith of the interconnection play a huge role when approximating communication overhead.[<cite><a href="https://computing.llnl.gov/tutorials/parallel_comp/">source</a></cite>] Other than that there are other reasons why communication slows down a parallel system, e.g the time to actually implement a communication architecture.
In parallel computing the ratio between computation and communication is often used to classify a parallel system[<cite><a href="https://en.wikipedia.org/wiki/Granularity_(parallel_computing)">source</a></cite>]. The metric is called *granularity* and is usually defined as:

$$
G = \frac{time(computation)}{time(communication)}
$$

While it may be desired to maximize $G$ in the most cases (since communication is causing overhead), the desired value of $G$ which maximizes efficiency is dependant on the underlying problem. As an example, a small or *fine* granularity could help to reduce overhead due to load imbalance, because communication between the tasks ensure that no worker is going idle.[<cite><a href="https://computing.llnl.gov/tutorials/parallel_comp/">source</a></cite>]


### III) Do the workers need to synchronize?
Highly associated with task communication (synchronization implies communication). Dependant on the problem, it may be mandatory for the workers to synchronize at a certain point. Often implemented by establishing some sort of synchronization point where the workers have to "wait" for synchronization. Synchronization, as a form of communication is a critical part of a parallel software, because it is a core inhibitor of the overall parallel execution workflow.[<cite><a href="https://computing.llnl.gov/tutorials/parallel_comp/">source</a></cite>]

### IV) Are there natural data dependencies within problem?
The most critical part of designing parallel software is the identification of data dependencies. Data dependencies inhibit parallelism as demonstrated in the Fibonacci-Example. Generally speaking, a (data) *"dependence exists between program statements when the order of statement execution affects the results of the program."*[<cite><a href="https://computing.llnl.gov/tutorials/parallel_comp/">source</a></cite>]
Dependant data in its simplest form is demonstrated in the code below
```python
x = 1
y = 2
z = x+y
w = z**y
```
Although it is possible to assign this kind of workflow to more than one worker (For example in a shared memory environment), there would probably be an increase in computation time due to synchronization and therefore no need to run this piece of code in parallel. This is why there may be serial parts within a parallel program[<cite><a href="https://computing.llnl.gov/tutorials/parallel_comp/">source</a></cite>]


### V) Is Load Balancing necessary?
For a parallel system with $n$ workers the programmer seeks to distribute the overall problem (instructions+data) into $n$ roughly equal-sized chunks of work in order to keep all workers busy and avoid idle time. This is not trivial because the performance of the entire system depends on the slowest worker.[<cite><a href="https://en.wikipedia.org/wiki/Load_balancing_(computing)">source</a></cite>] In a SIMD-scenario this is not a big concern as the data is often array- or cube-like, where the $n$-partitioning is applicable. 
If the computation time is intentionally variable and/or not predictable, the programmer needs to implement a mechanism which redistributes remaining work. A logical solution to this is described by the concept of *work stealing*, which refers to a mechanism where idle workers support busy workers to decrease computation time.[<cite><a href="https://en.wikipedia.org/wiki/Work_stealing">source</a></cite>] Manually implementing this kind of mechanism is not easy because it comes with drawbacks such as additional communication and data traffic which needs to be taken care of. A much easier and more straight-forward way to decrease idle time is the *Task-Pool*, where a pool of tasks is shared globally, enabling all workers to request work and submit results.[<cite><a href="https://computing.llnl.gov/tutorials/parallel_comp/">source</a></cite>]

## Parallel Harvesting
As an example to demonstrate the combination of inital topic and parallel computing, consider a hypothetical scenario, where a researcher wants to run an explorative Analysis of the business entities of several towns. Such an analysis can yield both research insights and business value (actually, the structured data itself could). After the researcher has not found comprehensive, ready-to-use information about this subject, he could try to collect the desired data by himself. For this particular problem the hypothetical workflow could look something like this :
-   **Collect data about the entities**

We could further assume that there is a set of towns, where each town is a set of entites. For every entity, the data regarding this entity is requested, processed and stored. It is the task of the researcher to find suitable data sources. He could use the following:
    - OSM-API : Business information, location data, historic data
    - Scrape Facebook : Business information, sentiment data, employee data
    - Twitter-API : Sentiment data
    - Google-API : Sentiment data, business information, location data

-  **Build a harvester**

The harvester consists of a set of distinct functions.
    - Request Data
    - Validate Data
    - Clean Data
    - Aggregate + Integrate Data
    - Transform data
    - Store Data
    

For better readability and simplicity, I have aggregated the hypothetical set of functions into ```request``` and ```clean``` which serve as constructors to call the functions needed.


```python
def request(entity, source):
    #Simulate some requesting computations
    #Add two additional seconds for scraping FB because it requires more overhead than the api calls
    sleep(np.random.random() + 3) if source == "FB" else sleep(np.random.random() + 1)
def clean(entity, source):
    #Simulate some cleaning computations
    sleep(1)
def merge(data):
    # Aggregate/Integrate
    sleep(.5)
```

### Serial Solution

For a given entity, the data is iteratively collected, and cleansed. I will use `example` to demonstrate the acquisition of data for  a single entity


```python
def serial_harvest(entity):
    data = {}
    for source in ["FB", "OSM", "TWTR", "GOOG"]:
        response = request(entity, source)
        data[source] = clean(response, source)
    return merge(data)
```


```python
%time example = serial_harvest("Marstall-Mensa")
```

    CPU times: user 11.1 ms, sys: 4.39 ms, total: 15.5 ms
    Wall time: 12.6 s


### Parallel Solution


```python
# First we need to create an object which holds the instructions
parallel_pipe = lambda entity : { "entity" : (entity),
           "request-0" : (request, "entity", "OSM"),
           "request-1" : (request, "entity", "FB"),
           "request-2" : (request, "entity", "TWTR"),
           "request-3" : (request, "entity", "GOOG"),  
             "clean-0" : (clean, "request-0", "OSM" ),
             "clean-1" : (clean, "request-1", "FB" ),
             "clean-2" : (clean, "request-2", "TWTR" ),
             "clean-3" : (clean, "request-3", "GOOG" ),                                     
               "merge" : (merge,['clean-%d' % i for i in range(4)] )}
```


```python
parallel_pipe("Marstall-Mensa")
```




    {'clean-0': (<function __main__.clean>, 'request-0', 'OSM'),
     'clean-1': (<function __main__.clean>, 'request-1', 'FB'),
     'clean-2': (<function __main__.clean>, 'request-2', 'TWTR'),
     'clean-3': (<function __main__.clean>, 'request-3', 'GOOG'),
     'entity': 'Marstall-Mensa',
     'merge': (<function __main__.merge>,
      ['clean-0', 'clean-1', 'clean-2', 'clean-3']),
     'request-0': (<function __main__.request>, 'entity', 'OSM'),
     'request-1': (<function __main__.request>, 'entity', 'FB'),
     'request-2': (<function __main__.request>, 'entity', 'TWTR'),
     'request-3': (<function __main__.request>, 'entity', 'GOOG')}



The created object may look confusing, but it holds all information needed to coordinate possibilites for parallelization and it is also useful in terms of visualization. Visualization can often help to optimize certain workflows.


```python
from dask import visualize
from dask.threaded import get as compute
```


```python
visualize(parallel_pipe("Marstall-Mensa"),rankdir="LR")
```




![png](output_66_0.png)



*Note* : The rectangles represent returned or assigned objects.


```python
# send graph to workers and tell them that "merge" needs to be calculated.
# Calculating the "merge"-node requires the workers to split up the work as visualized above.
# Note that the workers share memory and "entity" is assigned by only one worker
%time compute(parallel_pipe("Marstall-Mensa"), 'merge') 
```

    CPU times: user 10.5 ms, sys: 4.4 ms, total: 14.9 ms
    Wall time: 5.32 s



```python
est_serial = lambda : ((np.random.random() + 1)+
             (np.random.random() + 1)+
             (np.random.random() + 1)+
             (np.random.random() + 3)+4.5)
est_parallel = lambda : sum([np.random.random()+3,1.5 ])
approx_time = pd.DataFrame({"$serial$" : [ est_serial() for _ in range(1000)],
              "$parallel$" : [ est_parallel() for _ in range(1000)]})
approx_time.index = [ _ for _ in range(1,1001)]
approx_time.index.name = "$entity_n$"
```


```python
approx_time["$serial$"].mean(), approx_time["$parallel$"].mean()
```




    (12.49960457394786, 4.995933115188611)



In this example, the randomness associated with the requesting time of the api calls and the additional bottleneck of `request(entity, source="FB")`, which causes a load imbalance on the 4 workers, leads to an overall speedup of only approximately $2-3$. In reality there is less randomness related to api calls and scrape requests, such that the maximum speedup can be achieved. Also note that the calculations of `approx_time` are very superficial.


```python
fig, axes = plt.subplots(1,2)
(approx_time/60).plot(ax=axes[0], title="elapsed time per entity. ($\min$)", grid=True)
(approx_time/60).cumsum().plot(ax=axes[1], title="cumulative time elapsed. ($\min$)", grid=True)
plt.tight_layout()
```


![png](output_72_0.png)


### Conclusion
Data Acquisition and Preprocessing are both important topics for social scientists, because it enables a researcher to make use of the rich data that can be harvested from all kinds of sources in order to run novel analysis. Furthermore, the use of parallel hardware allows the researcher to scale up his projects. That being said, most researchers have access to high-performance computer clusters within their institute/organization, where the knowledge of parallelizing code is equally applicable.

